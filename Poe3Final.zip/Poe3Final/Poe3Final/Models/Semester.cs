﻿using System.ComponentModel.DataAnnotations;

namespace Poe3Final.Models
{
    public class Semester
    {
        [Key]
        public int SemId { get; set; }
        public string Name { get; set; }
    }
}
