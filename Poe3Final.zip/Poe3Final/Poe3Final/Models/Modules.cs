﻿using System.ComponentModel.DataAnnotations;

namespace Poe3Final.Models
{
    public class Modules
    {
        [Key]
        public int ModId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public int Hours { get; set; }
    }
}
