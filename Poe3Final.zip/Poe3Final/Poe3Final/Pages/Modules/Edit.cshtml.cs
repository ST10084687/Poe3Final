﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Poe3Final.Data;

namespace Poe3Final.Models
{
    public class EditModel : PageModel
    {
        private readonly Poe3Final.Data.ApplicationDbContext _context;

        public EditModel(Poe3Final.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Modules Modules { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Modules = await _context.Modules.FirstOrDefaultAsync(m => m.ModId == id);

            if (Modules == null)
            {
                return NotFound();
            }
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Modules).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ModulesExists(Modules.ModId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool ModulesExists(int id)
        {
            return _context.Modules.Any(e => e.ModId == id);
        }
    }
}
