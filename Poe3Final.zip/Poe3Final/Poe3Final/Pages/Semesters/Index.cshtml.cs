﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Poe3Final.Data;
using Poe3Final.Models;

namespace Poe3Final.Pages.Semesters
{
    public class IndexModel : PageModel
    {
        private readonly Poe3Final.Data.ApplicationDbContext _context;

        public IndexModel(Poe3Final.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Semester> Semester { get;set; }

        public async Task OnGetAsync()
        {
            Semester = await _context.Semester.ToListAsync();
        }
    }
}
