﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Poe3Final.Models;

namespace Poe3Final.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Poe3Final.Models.Semester> Semester { get; set; }
        public DbSet<Poe3Final.Models.Modules> Modules { get; set; }
    }
}
